C and C++ README

For C/C++ support for Thorlabs camera series CC215MU, CS126, CS135, CS165, CS2100, CS235, CS505, and CS895), please follow these directions:

1. Install the SDK using the installation instructions in THORLABS_SDK_INSTALLATION_INSTRUCTIONS.txt

2. See the following API references to get familiar with the SDK:

 Thorlabs_Camera_C_API_Reference.pdf
 and
 Thorlabs_Mono_To_Color_Processing_C_API_Reference.pdf
 
3. To access the functions in the DLLs, helper functions are provided in several source files that have the suffix *_load.c. These can be found in the SDK/Native_Compact_Scientific_Camera_Toolkit/load folder (the header files are all located in the /include folder). These helper functions look up the DLL function addresses and assign them to external variables that can directly called. Please see the provided example applications for details.

 For example, the tl_camera_sdk_load.c and tl_camera_sdk_load.h files provide
 
 tl_camera_sdk_dll_initialize()
 and
 tl_camera_sdk_dll_terminate()

4.a Remember to link with libdl when using the load files because they make calls to dlopen, dlsym, dlclose, etc...

 GCC link option for linking libdl: -Wl,--no-as-needed -ldl

4.b If you are using frame available callbacks, such as in the callback examples, and you use thread synchronization objects, remember to link with libpthread.
 
 GCC link option for linking libpthread: -pthread

4.c If you are using the coloring suite, such as in the advanced color examples, you need to link the math library as well.

 GCC link option for linking libm: -lm

5. Be sure to always close cameras, close the SDK, and terminate the dll before exiting your application. Otherwise, crashes can occur upon exit.
