Python README

For Python support for Thorlabs camera series CC215MU, CS126, CS135, CS165, CS2100, CS235, CS505, and CS895), please follow these directions:

The Python SDK is a wrapper around the native SDK, which means python applications using this package need visibility of the native DLLS.

To install the Python SDK, please follow these directions:

1. Install the SDK using the installation instructions in THORLABS_SDK_INSTALLATION_INSTRUCTIONS.txt

2. The Python SDK is provided both as an installable package and as source files. To install the Python SDK in your environment, use a package manager such as pip to install from file. 

 example install command: 'python.exe -m pip install thorlabs_tsi_camera_python_sdk_package.zip'  

 This will install the thorlabs_tsi_sdk package into your current environment. The examples assume you are using this method. 
 If you want to use the source files directly, they are included in SDK\Python Toolkit\source.

3. A requirements.txt file is provided in the examples folder that lists the libraries needed to run the examples (besides the thorlabs_tsi_sdk package). This can be used with pip to install each dependency at once:

   pip install -r requirements.txt  

4. See the following guide for help with the Python SDK:

   Thorlabs_Camera_Python_API_Reference.pdf

5. Be sure to always dispose of cameras and the SDK before exiting your application. Otherwise, crashes can occur upon exit.